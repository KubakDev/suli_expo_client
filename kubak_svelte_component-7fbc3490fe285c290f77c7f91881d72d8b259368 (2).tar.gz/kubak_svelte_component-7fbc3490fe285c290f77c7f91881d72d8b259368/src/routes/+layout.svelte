<script lang="ts">
	import '../style.css';
	import '../app.postcss';
</script>

<slot />
