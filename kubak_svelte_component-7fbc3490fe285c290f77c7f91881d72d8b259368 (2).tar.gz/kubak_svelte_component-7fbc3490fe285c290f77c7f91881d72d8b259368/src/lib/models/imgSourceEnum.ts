export enum ImgSourceEnum {
  local = 'local',
  remote = 'remote',
}