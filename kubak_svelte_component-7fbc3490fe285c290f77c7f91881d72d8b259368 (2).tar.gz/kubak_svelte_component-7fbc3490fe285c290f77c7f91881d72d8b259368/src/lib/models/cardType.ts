export enum CardType {
	Main = 'main',
	Square = 'square',
	Flat = 'flat',
	Simple = 'simple',
	Video = 'video'
}
