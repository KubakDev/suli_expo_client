<div class="h-[300px] w-full bg-red-600" />
