<script lang="ts">
	export let title: string;
</script>

<div class="m-4 border-y-2 border-[#e1b168] w-36 flex justify-center">
	<h1>{title}</h1>
</div>
